<?php include "includes/init.php" ?>
<!DOCTYPE html>
<html lang="en">
    <?php include "includes/header.php" ?>
    <body>
        

        <div class="grid-container">
    <div class="header">
        <?php include "includes/nav.php" ?>
    </div>
    <div class="left">
      
      
    </div>
    <div class="right">
      <div id="map"></div>

      <div id="popup" class="ol-popup">
        <a href="#" id="popup-closer" class="ol-popup-closer"></a>
        <div id="popup-content"></div>
      </div>
    </div>
  </div>



  <!-- Inclure le fichier JavaScript d'OpenLayers -->
  <script src="main.js"></script>
    
        
    </body>
</html>