<?php include("../includes/init.php");?>
<?php 
    if (logged_in()) {
        $username=$_SESSION['username'];
        if (!verify_user_group($pdo, $username, "Editeur") && !verify_user_group($pdo, $username, "Partenaire Editeur")) {
            set_msg("User '{$username}' does not have permission to view this page");
            redirect('../index.php');
        }
    } else {
        set_msg("Please log-in and try again");
        redirect('../index.php');
    } 
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>DJ Basin Client</title>
        <link rel="stylesheet" href="src/leaflet.css">
        <link rel="stylesheet" href="src/css/bootstrap.css">
        <link rel="stylesheet" href="src/plugins/L.Control.MousePosition.css">
        <link rel="stylesheet" href="src/plugins/L.Control.Sidebar.css">
        <link rel="stylesheet" href="src/plugins/Leaflet.PolylineMeasure.css">
        <link rel="stylesheet" href="src/plugins/easy-button.css">
        <link rel="stylesheet" href="src/css/font-awesome.min.css">
        <link rel="stylesheet" href="src/plugins/leaflet.awesome-markers.css">
        <link rel="stylesheet" href="src/plugins/MarkerCluster.css">
        <link rel="stylesheet" href="src/plugins/MarkerCluster.Default.css">
        <link rel="stylesheet" href="src/plugins/leaflet-legend.css">
        <link rel="stylesheet" href="src/jquery-ui.min.css">
        
        <script src="src/leaflet.js"></script>
        <script src="src/jquery-3.3.1.min.js"></script>
        <script src="src/plugins/L.Control.MousePosition.js"></script>
        <script src="src/plugins/L.Control.Sidebar.js"></script>
        <script src="src/plugins/Leaflet.PolylineMeasure.js"></script>
        <script src="src/plugins/easy-button.js"></script>
        <script src="src/plugins/leaflet-providers.js"></script>
        <script src="src/plugins/leaflet.ajax.min.js"></script>
        <script src="src/plugins/leaflet.awesome-markers.min.js"></script>
        <script src="src/plugins/leaflet.markercluster.js"></script>
        <script src="src/plugins/leaflet-legend.js"></script>
        <script src="src/jquery-ui.min.js"></script>
        <script src="src/turf.min.js"></script>

        <style>
            #mapdiv {
                height:100vh;
            }

            .col-xs-12, .col-xs-6, .col-xs-4 {
                padding:3px;
            }

            #divProject {
                background-color: beige;
            }
            
            #divBUOWL {
                background-color: #ffffb3;
            }
            
            #divEagle {
                background-color: #ccffb3;
            }
            
            #divRaptor {
                background-color: #e6ffff;
            }
            
            .errorMsg {
                padding:0;
                text-align:center;
                background-color:darksalmon;
            }
            
            .text-labels {
                font-size:16px;
                font-weight: bold;
                color:red;
                background: aqua;
                text-align: center;
                display: inline-block;
                padding: 5pt;
                border: 3px double darkred;
                border-radius: 5pt;
                margin-left: -15pt;
                margin-top: -8pt;
            }
            
            .eagle-labels {
                font-size:12px;
                font-weight: bold;
                color:white;
                background: black;
                text-align: center;
                display: inline-block;
                padding: 5pt;
                border: 3px double red;
                border-radius: 5pt;
                margin-left: -20pt;
                margin-top: -32pt;
            }
            
        </style>
    </head>
    <body>
        <div id="side-bar" class="col-md-3">
            <button id='btnLocate' class='btn btn-primary btn-block'>Locate</button>
            <button id="btnShowLegend" class='btn btn-primary btn-block'>Show Legend</button>
            <div id="legend">
                <div id="lgndClientLinears">
                    <h4 class="text-center">Linear Projects <i id="btnLinearProjects" class="fa fa-server"></i></h4>
                    <div id="lgndLinearProjectsDetail">
                        <svg height="270" width="100%">
                            <line x1="10" y1="10" x2="40" y2="10" style="stroke:peru; stroke-width:2;"/>
                            <text x="50" y="15" style="font-family:sans-serif; font-size:16px;">Pipeline</text>
                            <line x1="10" y1="40" x2="40" y2="40" style="stroke:navy; stroke-width:2;"/>
                            <text x="50" y="45" style="font-family:sans-serif; font-size:16px;">Flowline</text>
                            <line x1="10" y1="70" x2="40" y2="70" style="stroke:navy; stroke-width:2;stroke-dasharray: 5,5"/>
                            <text x="50" y="75" style="font-family:sans-serif; font-size:16px;">Flowline - Estimated</text>
                            <line x1="10" y1="100" x2="40" y2="100" style="stroke: darkgreen; stroke-width: 2;"/>
                            <text x="50" y="105" style="font-family: sans-serif; font-size: 16px">Electric Line</text>
                            <line x1="10" y1="130" x2="40" y2="130" style="stroke: darkred; stroke-width: 2;"/>
                            <text x="50" y="135" style="font-family: sans-serif; font-size: 16px">Access Road - Confirmed</text>
                            <line x1="10" y1="160" x2="40" y2="160" style="stroke: darkred; stroke-width: 2; stroke-dasharray: 5, 5;"/>
                            <text x="50" y="165" style="font-family: sans-serif; font-size: 16px">Access Road - Estimated</text>
                            <line x1="10" y1="190" x2="40" y2="190" style="stroke: indigo; stroke-width: 2;"/>
                            <text x="50" y="195" style="font-family: sans-serif; font-size: 16px">Extraction</text>
                            <line x1="10" y1="220" x2="40" y2="220" style="stroke: darkgoldenrod; stroke-width: 2;"/>
                            <text x="50" y="225" style="font-family: sans-serif; font-size: 16px">Other</text>
                            <rect x="10" y="240" width="30" height="20" style="stroke-width: 4; stroke: gray; stroke-dasharray: 5, 5; fill: yellow; fill-opacity:0.0;"/>
                            <text x="50" y="255" style="font-family: sans-serif; font-size: 16px;">Right-of-way</text>
                        </svg>
                    </div>
                </div>
                <div id="lgndBurrowingOwlHabitat">
                    <h4 class="text-center">Burrowing Owl Habitat <i id="btnBUOWL" class="fa fa-server"></i></h4>
                    <div id="lgndBUOWLDetail">
                        <svg height="90">
                            <rect x="10" y="5" width="30" height="20" style="stroke-width: 4; stroke: deeppink; fill: yellow; fill-opacity:0.5;"/>
                            <text x="50" y="20" style="font-family: sans-serif; font-size: 16px;">Historically Occupied</text>
                            <rect x="10" y="35" width="30" height="20" style="stroke-width: 4; stroke: yellow; fill: yellow; fill-opacity:0.5;"/>
                            <text x="50" y="50" style="font-family: sans-serif; font-size: 16px;">Not Historically Occupied</text>
                            <rect x="10" y="65" width="30" height="20" style="stroke-width: 4; stroke: yellow; stroke-dasharray: 5, 5; fill: yellow; fill-opacity:0.0;"/>
                            <text x="50" y="80" style="font-family: sans-serif; font-size: 16px;">300m Buffer</text>
                        </svg>
                    </div>
                </div>
                <div id="lgndEagleNest">
                    <h4 class="text-center">Eagle Nests <i id="btnEagle" class="fa fa-server"></i></h4>
                    <div id="lgndEagleDetail">
                        <svg height="60">
                            <circle cx="25" cy="15" r="10" style="stroke-width: 4; stroke: deeppink; fill: chartreuse; fill-opacity:0.5;"/>
                            <text x="50" y="20" style="font-family: sans-serif; font-size: 16px;">Active Nest</text>
                            <circle cx="25" cy="45" r="10" style="stroke-width: 4; stroke: chartreuse; fill: chartreuse; fill-opacity:0.5;"/>
                            <text x="50" y="50" style="font-family: sans-serif; font-size: 16px;">Unknown status</text>
                        </svg>
                    </div>
                </div>
                <div id="lgndRaptorNest">
                    <h4 class="text-center">Raptor Nests <i id="btnRaptor" class="fa fa-server"></i></h4>
                    <div id="lgndRaptorDetail">
                        <svg height="90">
                            <circle cx="25" cy="15" r="10" style="stroke-width: 4; stroke: deeppink; fill: cyan; fill-opacity:0.5;"/>
                            <text x="50" y="20" style="font-family: sans-serif; font-size: 16px;">Active Nest</text>
                            <circle cx="25" cy="45" r="10" style="stroke-width: 4; stroke: deeppink; stroke-dasharray: 5, 5; fill: cyan; fill-opacity:0.5;"/>
                            <text x="50" y="50" style="font-family: sans-serif; font-size: 16px;">Fledged Nest</text>
                            <circle cx="25" cy="75" r="10" style="stroke-width: 4; stroke: cyan; fill: cyan; fill-opacity:0.5;"/>
                            <text x="50" y="80" style="font-family: sans-serif; font-size: 16px;">Unknown status</text>
                        </svg>
                    </div>
                </div>
                <div id="lgndGBHRookeries">
                    <h4 class="text-center">Heron Rookeries <i id="btnGBH" class="fa fa-server"></i></h4>
                    <div id="lgndGBHDetail">
                        <svg height="40">
                            <rect x="10" y="5" width="30" height="20" style="stroke-width: 4; stroke: fuchsia; fill: fuchsia; fill-opacity:0.5;"/>
                        </svg>
                    </div>
                </div>
            </div>
            <div id="divProject" class="col-xs-12">
                <div id="divProjectLabel" class="text-center col-xs-12">
                    <h4 id="lblProject">Linear Projects</h4>
                </div>
                <div id="divProjectError" class="errorMsg col-xs-12"></div>
                <div id="divFindProject" class="form-group has-error">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindProject" class="form-control" placeholder="Project ID">
                    </div>
                    <div class="col-xs-6">
                        <button id="btnFindProject" class="btn btn-primary btn-block" disabled>Find Project</button>
                    </div>
                </div>
                <div id="divFilterProject" class="col-xs-12">
                    <div class="col-xs-4">
                        <input type='checkbox' name='fltProject' value='Pipeline' checked>Pipelines<br>
                        <input type='checkbox' name='fltProject' value='Road' checked>Access Roads
                        <button id="btnProjectFilterAll" class="btn btn-primary btn-block">Check All</button>
                    </div>
                    <div class="col-xs-4">
                        <input type='checkbox' name='fltProject' value='Electric' checked>Electric Lines<br>
                        <input type='checkbox' name='fltProject' value='Extraction' checked>Extractions
                        <button id="btnProjectFilterNone" class="btn btn-primary btn-block">Uncheck All</button>
                    </div>
                    <div class="col-xs-4">
                        <input type='checkbox' name='fltProject' value='Flowline' checked>Flowlines<br>
                        <input type='checkbox' name='fltProject' value='Other' checked>Other
                        <button id="btnProjectFilter" class="btn btn-primary btn-block">Filter</button>
                    </div>
                </div>
                <div class="" id="divProjectData"></div>
            </div>
            <div id="divBUOWL" class="col-xs-12">
                <div id="divBUOWLLabel" class="text-center col-xs-12">
                    <h4 id="lblBUOWL">BUOWL Habitat</h4>
                </div>
                <div id="divBUOWLError" class="errorMsg col-xs-12"></div>
                <div id="divFindBUOWL" class="form-group has-error">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindBUOWL" class="form-control" placeholder="Habitat ID">
                    </div>
                    <div class="col-xs-6">
                        <button id="btnFindBUOWL" class="btn btn-primary btn-block" disabled>Find BUOWL</button>
                    </div>
                </div>
                <div id="divFilterBUOWL" class="col-xs-12">
                    <div class="col-xs-4">
                        <input type='radio' name='fltBUOWL' value='ALL' checked>All
                    </div>
                    <div class="col-xs-4">
                        <input type='radio' name='fltBUOWL' value='Yes'>Historically Occupied
                    </div>
                    <div class="col-xs-4">
                        <input type='radio' name='fltBUOWL' value='Undetermined'>Undetermined
                    </div>
                </div>
                <div class="" id="divBUOWLData"></div>
            </div>
            <div id="divEagle" class="col-xs-12">
                <div id="divEagleLabel" class="text-center col-xs-12">
                    <h4 id="lblEagle">Eagle Nests</h4>
                </div>
                <div id="divEagleError" class="errorMsg col-xs-12"></div>
                <div id="divFindEagle" class="form-group has-error">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindEagle" class="form-control" placeholder="Eagle Nest ID">
                    </div>
                    <div class="col-xs-6">
                        <button id="btnFindEagle" class="btn btn-primary btn-block" disabled>Find Eagle Nest</button>
                    </div>
                </div>
                <div id="divFilterEagle" class="col-xs-12">
                    <div class="col-xs-4">
                        <input type='radio' name='fltEagle' value='ALL' checked>All
                    </div>
                    <div class="col-xs-4">
                        <input type='radio' name='fltEagle' value='ACTIVE NEST'>Active
                    </div>
                    <div class="col-xs-4">
                        <input type='radio' name='fltEagle' value='INACTIVE LOCATION'>Inactive
                    </div>
                </div>
                <div class="" id="divEagleData"></div>
            </div>
            <div id="divRaptor" class="col-xs-12">
                <div id="divRaptorLabel" class="text-center col-xs-12">
                    <h4 id="lblRaptor">Raptor Nests</h4>
                </div>
                <div id="divRaptorError" class="errorMsg col-xs-12"></div>
                <div id="divFindRaptor" class="form-group has-error">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindRaptor" class="form-control" placeholder="Raptor Nest ID">
                    </div>
                    <div class="col-xs-6">
                        <button id="btnFindRaptor" class="btn btn-primary btn-block" disabled>Find Raptor Nest</button>
                    </div>
                </div>
                <div id="divFilterRaptor" class="col-xs-12">
                    <div class="col-xs-3">
                        <input type='radio' name='fltRaptor' value='ALL' checked>All
                    </div>
                    <div class="col-xs-3">
                        <input type='radio' name='fltRaptor' value='ACTIVE NEST'>Active
                    </div>
                    <div class="col-xs-3">
                        <input type='radio' name='fltRaptor' value='INACTIVE NEST'>Inactive
                    </div>
                    <div class="col-xs-3">
                        <input type='radio' name='fltRaptor' value='FLEDGED NEST'>Fledged
                    </div>
                </div>
                <div class="" id="divRaptorData"></div>
            </div>
        </div>
        <div id="mapdiv" class="col-md-12"></div>
        
    </body>
</html>