        <div class="container">
            <p class="text-center">&copy; <a href='/<?php  echo $root_directory?>/index.php'>SIG d'El Jadida</a> 2023</p>
        </div> <!--Container-->
