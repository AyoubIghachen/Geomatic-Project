    <head>
        <meta charset="UTF-8">
        <title>ImaginaryEnv</title>
        <link rel="stylesheet" href="/<?php echo $root_directory ?>/css/bootstrap.css">
        <link rel="stylesheet" href="/<?php echo $root_directory ?>/css/style.css">
        <script src="/<?php  echo $root_directory?>/resources/jquery.min.js"></script>
        <script src="/<?php  echo $root_directory?>/js/js_functions.js"></script>

        <!-- Inclure le fichier CSS d'OpenLayers -->
  <link rel="stylesheet" href="resources/ol/ol.css">
  
  <link rel="stylesheet" href="resources/layerswitcher/ol-layerswitcher.css">
  <link rel="stylesheet" href="style.css">
  <script src="resources/ol/ol.js"></script>
  <script src="resources/layerswitcher/ol-layerswitcher.js"></script>
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>


  <script src='https://api.tiles.mapbox.com/mapbox-gl-js/v0.44.2/mapbox-gl.js'></script>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v0.44.2/mapbox-gl.css' rel='stylesheet' />

    <script src='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v2.3.0/mapbox-gl-geocoder.min.js'></script>
    <link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-geocoder/v2.3.0/mapbox-gl-geocoder.css' type='text/css' />
    <script src='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.0.0/mapbox-gl-draw.js'></script>
    <link rel='stylesheet' href='https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.0.0/mapbox-gl-draw.css' type='text/css'/>
    
    </head>
   