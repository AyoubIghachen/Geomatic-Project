<?php include "includes/init.php" ?>
<!DOCTYPE html>
<html lang="en">
    <?php include "includes/header.php" ?>
    <body>
    <div class="grid-container">
    <div class="header">
        <?php include "includes/nav.php" ?>
    </div>
  </div>

        <div class="container">
            <?php 
                show_msg();
            ?>
            <h1 class="text-center"> El Jadida</h1>
            <p>Située à 96 km de Casablanca avec une population croissante de 214 000 Habitants, est l’une des villes en voie de développement dans le domaine touristique qui attire de plus en plus de visiteurs locaux et étrangers grâce à sa situation géographique située au bord de l’océan.

El Jadida est le nom actuel (depuis 1815) de l'ancienne Mazagão (Mazagan), cité fortifiée édifiée par les Portugais au début du XVIe siècle, qui ne fut reprise par les Marocains qu'en 1769.</p>
        </div> <!--Container-->
        
        <?php include "includes/footer.php" ?>
    </body>
</html>