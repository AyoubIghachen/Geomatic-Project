var container = document.getElementById('popup');
var content = document.getElementById('popup-content');
var closer = document.getElementById('popup-closer');

const overlay = new ol.Overlay({
    element: container,
});

var mapView = new ol.View ({
    center: ol.proj.fromLonLat([-8.497800054575647,33.2310034901695]),
    zoom: 13,
    enableRotation: false
});

var map = new ol.Map({
    target:'map',
    view: mapView,
    controls: ol.control.defaults().extend([
        new ol.control.ScaleLine(),
        new ol.control.FullScreen(),
        new ol.control.ZoomSlider(),
    ]),
    overlays: [overlay],
});



//******************************************************************************************** Bases Map
var osmTile = new ol.layer.Tile({
    title: 'Open Street Map',
    visibile: true,
    type:'base',
    source: new ol.source.OSM()
});

//map.addLayer(osmTile);


var SatTile = new ol.layer.Tile({
    title: 'Esri WorldImagery',
    visibile: true,
    type:'base',
    source: new ol.source.XYZ({
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
    }),
});

//map.addLayer(SatTile);

var baseGroup = new ol.layer.Group({
    title: 'Base Maps',
    fold: true,
    layers: [SatTile, osmTile]
});

map.addLayer(baseGroup);












//******************************************************************************************** Couches

// Couche voirie
const VoirieTile = new ol.layer.Vector({
    title: 'Voirie',
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3AVoirie&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: 'red',
            width: 0.25
        })
    })
});



// Couche zoning
const ZoningTile = new ol.layer.Vector({
    title: "Plan d'amenagement",
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3AZoning&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        fill: new ol.style.Fill({
            color: 'rgba(85, 164, 206, 0.3)'
        }),
        stroke: new ol.style.Stroke({
            color: 'blue',
            width: 0.5
        })
    })
});



// Couche pharmacie
const PharmacieTile = new ol.layer.Vector({
    title: 'Pharmacie',
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3APharmacie&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        image: new ol.style.Icon({
            src: 'resources/img/pharmacy3_icon.png',
            size: [800, 800],
            scale: 0.033
        })
    })
});
//PharmacieTile.setZIndex(1);



// Couche Transport
const TransportTile = new ol.layer.Vector({
    title: 'Transport',
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3ATransport&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        image: new ol.style.Icon({
            src: 'resources/img/Transport_icon4.png',
            size: [800, 800],
            scale: 0.033
        })
    })
});



// Couche Ports
const PortsTile = new ol.layer.Vector({
    title: 'Ports',
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3APorts&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        image: new ol.style.Icon({
            src: 'resources/img/Ports1.png',
            size: [800, 800],
            scale: 0.053
        })
    })
});



// Couche Mosque
const MosqueTile = new ol.layer.Vector({
    title: 'Mosque',
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3AMosque_cimitere&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        image: new ol.style.Icon({
            src: 'resources/img/mosque.png',
            size: [800, 800],
            scale: 0.043
        })
    })
});



// Couche Traffic
const TrafficTile = new ol.layer.Vector({
    title: 'Traffic',
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3Atraffic&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        image: new ol.style.Icon({
            src: 'resources/img/Traffic.png',
            size: [800, 800],
            scale: 0.033
        })
    })
});



// Couche Point_Interet
const Point_InteretTile = new ol.layer.Vector({
    title: "Point d'intérêt",
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3APoint_interet&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        image: new ol.style.Icon({
            src: 'resources/img/PointInteret1.png',
            size: [800, 800],
            scale: 0.083
        })
    })
});



// Couche Reseau_Feroviere
const Reseau_FeroviereTile = new ol.layer.Vector({
    title: "Réseau ferroviaire",
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3Areseau_feroviere&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: 'red',
            width: 2
        })
    })
});



// Couche Equipement
const EquipementTile = new ol.layer.Vector({
    title: "Equipement",
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3Aequipement&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        fill: new ol.style.Fill({
            color: 'rgba(85, 164, 206, 0.3)'
        }),
        stroke: new ol.style.Stroke({
            color: 'Red',
            width: 0.5
        })
    })
});



// Couche QE_Baignade
const QE_BaignadeTile = new ol.layer.Vector({
    title: "Qualité des eaux de baignade",
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3AQE_baignade-site&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        image: new ol.style.Icon({
            src: 'resources/img/QE_Baignade.png',
            size: [800, 800],
            scale: 0.083
        })
    })
});




// Couche Foret
const ForetTile = new ol.layer.Vector({
    title: "Foret",
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3Aforet&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        fill: new ol.style.Fill({
            color: 'rgba(13, 146, 82, 0.8)'
        }),
        stroke: new ol.style.Stroke({
            color: 'green',
            width: 0.5
        })
    })
});




// Couche Occupation sol
const OccupationSolTile = new ol.layer.Vector({
    title: "Occupation du sol",
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3AOccupation_sol&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        fill: new ol.style.Fill({
            color: 'rgba(190, 178, 151, 0.8)'
        }),
        stroke: new ol.style.Stroke({
            color: 'gray',
            width: 0.5
        })
    })
});




// Couche Moyen Dechet
const MoyenDechetTile = new ol.layer.Vector({
    title: "Moyen de dechet annuel",
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3AmoyeneDechet&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        fill: new ol.style.Fill({
            color: 'rgba(213, 225, 36, 0.5)'
        }),
        stroke: new ol.style.Stroke({
            color: 'gray',
            width: 0.5
        })
    })
});



// Couche Route
const RouteTile = new ol.layer.Vector({
    title: 'Route',
    source: new ol.source.Vector({
        url: 'http://localhost:8080/geoserver/GeomaticProjet/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=GeomaticProjet%3ARoads&outputFormat=application%2Fjson' + '&srsname=EPSG:3857',
        format: new ol.format.GeoJSON(),
    }),
    style:  new ol.style.Style({
        stroke: new ol.style.Stroke({
            color: 'blue',
            width: 0.4
        })
    })
});




var layerGroup = new ol.layer.Group({
    title: 'Layers',
    fold: true,
    layers: [MoyenDechetTile, OccupationSolTile, RouteTile, VoirieTile, EquipementTile, ForetTile, ZoningTile, TrafficTile, Reseau_FeroviereTile, Point_InteretTile, PharmacieTile, TransportTile, PortsTile, MosqueTile, QE_BaignadeTile]
});


map.addLayer(layerGroup);










//******************************************************************************************** Layer Switcher

var layerSwitcher = new ol.control.LayerSwitcher({
    activationMode: 'click',
    stratActive: false,
    groupSelectStyle: 'children'
});

map.addControl(layerSwitcher);

/*function toggleLayer(eve){
    var lyrname = eve.target.value;
    var checkedStatus = eve. target.checked;
    var lyrList = map.getLayers();

    lyrList.forEach(function(element){
        if(lyrname == element.get('title')){
            element.setVisible(checkedStatus);
        }
    });
}*/


//******************************************************************************************** Mouse Position

var mousePosition = new ol.control.MousePosition({
    className: 'mousePosition',
    projection: 'EPSG:4326',
    coordinateFormat: function(coordinate){return ol.coordinate.format(coordinate,'{x} , {y}', 6);}
});
map.addControl(mousePosition);










//******************************************************************************************** FeatureInfo Popup

map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == MoyenDechetTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/MoyenDechet.png" alt="Occupation du sol image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: yellow;">Moyen de dechet annuel</p> </div>';
        popupContent += '<h4> Moyenne annuel: </h4>' + feature.get('déch_mén');
        popupContent += '<h4> Surface: </h4>' + feature.get('shape_area');

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});



map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == OccupationSolTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/OccupationSol.png" alt="Occupation du sol image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: gray;">Occupation du sol</p> </div>';
        popupContent += '<h4> Class: </h4>' + feature.get('fclass');
        popupContent += '<h4> Nom: </h4>' + feature.get('name');

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});


map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == ZoningTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/PA_2.jpg" alt="PA image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: blue;">Plan d amenagement</p> </div>';
        popupContent += '<h4> Code zoning: </h4>' + feature.get('code_zonin') + ' (' + feature.get('designatio').toLowerCase() + ')';
        popupContent += '<h4> Resume: </h4>' + feature.get('resume_zon').toLowerCase();

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});


map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == QE_BaignadeTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/QE_Baignade.png" alt="Equipement image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: black;">Qualité des eaux de baignade</p> </div>';
        popupContent += '<h4> Coordonnee: </h4>' + feature.get('coordonnee');
        popupContent += '<h4> Qualité 2019: </h4>' + feature.get('qual_2019');

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});


map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == EquipementTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/Equipement.png" alt="Equipement image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: black;">Equipement</p> </div>';
        popupContent += '<h4> Class: </h4>' + feature.get('classe_equ');
        popupContent += '<h4> Designation: </h4>' + feature.get('designatio');
        popupContent += '<h4> Observation: </h4>' + feature.get('observatio');

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});



map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == Point_InteretTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/PointInteret1.png" alt="Point Interet image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: black;">Point d interet</p> </div>';
        popupContent += '<h4> Class: </h4>' + feature.get('fclass');
        popupContent += '<h4> Nom: </h4>' + feature.get('name');

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});


map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == TrafficTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/Traffic.png" alt="Traffic image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: cyan;">Traffic</p> </div>';
        popupContent += '<h4> Class: </h4>' + feature.get('fclass');
        popupContent += '<h4> Nom: </h4>' + feature.get('name');

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});


map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == MosqueTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/mosque.png" alt="mosque image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: orange;">Lieu religieux</p> </div>';
        popupContent += '<h4> Type: </h4>' + feature.get('fclass');
        popupContent += '<h4> Nom: </h4>' + feature.get('name');

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});

map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == TransportTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/Transport_icon4.png" alt="Transport image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: blue;">Transport</p> </div>';
        popupContent += '<h4>' + feature.get('nom_fr') + '</h4>';
        popupContent += '<p> Adresse: ' + feature.get('adresse') + '</p>';
        popupContent += '<p> Telephone: ' + feature.get('telephone1') + '</p>';

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});

map.on('click', function (evt){
    var feature = map.forEachFeatureAtPixel(evt.pixel,function(feature,layer){
        if(layer == PharmacieTile){
            return feature;
        }
    });
    if(feature){
        var popupContent = '<div style="display: flex; align-items: center;"> <img src="/resources/img/pharmacy3_icon.png" alt="Pharmacy image" style="width: 50px; height: 50px;"> <p style="margin-left: 10px; color: green;">Pharmacy</p> </div>';
        popupContent += '<h4>' + feature.get('nom_fr') + '</h4>';
        popupContent += '<p> Adresse: ' + feature.get('adresse') + '</p>';
        popupContent += '<p> Telephone: ' + feature.get('telephone1') + '</p>';

        content.innerHTML = popupContent;
        const coordinate = evt.coordinate;
        overlay.setPosition(coordinate);
    }
});



closer.onclick = function(){
    overlay.setPosition(undefined);
};


//******************************************************************************************** Marker vector

const marker = new ol.layer.Vector({
    source: new ol.source.Vector({
        features: [
        new ol.Feature({
            geometry: new ol.geom.Point(ol.proj.fromLonLat([-8.510480,33.263496])),
        })
        ]
    }),
    style: new ol.style.Style({
        image: new ol.style.Icon({
        anchor: [0.5, 1],
        crossOrigin: 'anonymous',
        src: 'resources/img/marker-icon.png',
        })
    })
});

map.addLayer(marker);